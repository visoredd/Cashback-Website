<?php
// Include FB config file && User class

require_once 'glogin.php';
?>