<!DOCTYPE html>
<html>
<head>
</head>
<body>
	<a href="./display.php?data=Data1&data2=Data120">Click here</a>
</body>
</html>