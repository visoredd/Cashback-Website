<div class="profile-sidebar">
				<div class="profile-info border-bottom-grey">
					<img class="profile-pic" src="https://d1nrhamtcpp354.cloudfront.net/modules/web/assets/images/default_user.png">
					<div class="profile-user-name"> <?php echo $userData['first_name']; ?> 
						<div class="profile-user-available-amt">Available: <span>Rs. <?php echo $ca;?> </span>
						</div>
						<div class="profile-user-pending-amt">Pending: <span>Rs. 0 </span>
						</div>
					</div>
				</div>
				<div id="sidetabs" class="profile-tabs">
					<div class="sidetab">
						<a  href="overview.php" class="router-link-active">
							<div>
								<div class="itag profile-sprite overview">
								</div>
								<span class="innerSpan"> Overview </span>
							</div>
						</a>
					</div>
					<div class="sidetab">
						<a href="withdraw.php">
							<div>
								<div class="itag profile-sprite user-transfer"></div>
								<span class="innerSpan"> Withdraw Money </span>
							</div>
						</a>
					</div>
					<div class="sidetab">
						<a href="cashbackactivity.php">
							<div>
								<div class="itag profile-sprite cashback-activity-sidebar"></div><span class="innerSpan"> Cashback Activity </span>
							</div>
						</a>
					</div>
					<div class="sidetab">
						<a href="notification.php">
							<div>
								<i class="itag fa fa-bell-o"></i><span class="innerSpan"> All Notifications </span>
							</div>
						</a>
					</div>
					<div class="sidetab">
						<div class="side-show how-it-works-side-show">
							<div id="help-support-sidebar">
								<div class="itag profile-sprite help-support-sidebar"></div>
								<a href="/profile/support"><span class="innerSpan"> Help &amp; Support </span>
								</a>
								<span class="caret-right-icon"><i class="itag fa fa-caret-right arrow-height" style="line-height: 50px;"></i></span>
							</div>
						</div>
						<div class="sidetab-innerTab cHide">
							<a href="/profile/support/faqs" class="side-show">
								<div class="help-support-tab"><i class="itag fa fa-caret-right"></i><span class="" id="faq-tab">FAQ's</span>
								</div>
							</a>
							<div class="sidetab-innerTab cHide">
								<a href="#How CouponDunia Works-section" class="faq-section">
									<div><span>How CouponDunia Works</span></div>
								</a>
								<a href="#Cashback Facts-section" class="faq-section">
									<div><span>Cashback Facts</span>
									</div>
								</a>
								<a href="#Cashback Issues-section" class="faq-section">
									<div><span>Cashback Issues</span></div>
								</a>
								<a href="#Tracking-section" class="faq-section">
									<div><span>Tracking</span></div>
								</a>
								<a href="#Withdrawal-section" class="faq-section">
									<div><span>Withdrawal</span></div>
								</a>
								<a href="#Bonus-section" class="faq-section"><div><span>Bonus</span></div>
								</a>
								<a href="#Miscellaneous-section" class="faq-section">
									<div><span>Miscellaneous</span></div>
								</a>
								<a href="#Partner With Us-section" class="faq-section">
									<div><span>Partner With Us</span></div>
								</a>
							</div>
							<a href="/profile/support/missing-cashbacks">
								<div class="help-support-tab"><i class="itag fa fa-caret-right"></i><span class="">Cashback Issues</span>
								</div>
							</a>
							<a href="/profile/support/contact-us">
								<div class="help-support-tab"><i class="itag fa fa-caret-right"></i><span class="">Contact Us</span>
								</div>
							</a>
						</div>
					</div>
					<div class="sidetab">
						<a href="/profile/settings/info">
							<div><i class="itag fa fa-cog"></i><span class="innerSpan"> Profile &amp; Settings </span>
							</div>
						</a>
					</div>
				</div>
			</div>