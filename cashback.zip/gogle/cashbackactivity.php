<?php
        require_once 'user.php';
        require_once 'index.php'; 
        $mysqli = new mysqli("localhost", "root", "", "cashback");
        $result1 = $mysqli->query("SELECT email,cash,pending,available FROM cash WHERE email = '" . $userData['email'] . "'");
        if($result1 === FALSE) { 
            echo mysql_error(); // TODO: better error handling
        }else{
        while($row = mysqli_fetch_array($result1))
        {
            $ca= $row['cash'];
            $pen = $row['pending'];
            $av = $row['available'];
        }
        $result2 = $mysqli->query("SELECT * FROM cashback WHERE Useremail = '" . $userData['email'] . "'");
        while ($project =  mysqli_fetch_array($result2))
        {
            $paytm = $project['Pphone'];
            $bank = $project['IFSC'];
            $baccno = $project['BaccNo'];
            $baccty = $project['BaccTy'];
            $bacadr = $project['Baddr'];
            $bphone = $project['Bphone'];
            $baccname = $project['Bname'];
            $gift = $project['Gemail'];
            $gphone = $project['Gphone'];
            $gcategory = $project['Gradio'];
            $active = $project['active'];
            $available = $project['amount'];
        }

    }
?>

<?php

if(isset($_POST['confirm'])){
        $date = date('m/d/Y h:i:s', time());
  $cashcash = $ca - $available;
  $querycash = $mysqli->query("UPDATE cash SET cash = '".$cashcash."' WHERE email = '".$userData['email']."' ");
  $deletecash = $mysqli->query("DELETE FROM cashback WHERE Useremail = '".$userData['email']."' ");
  $insertall = $mysqli->query("INSERT INTO paycash (Useremail, Pphone, IFSC, BaccNo, BaccTy, Baddr, BPhone, Bname, Gemail, Gphone, Gradio, amount, date) VALUES ('".$userData['email']."','".$paytm."','".$bank."', '".$baccno."', '".$baccty."', '".$bacadr."', '".$bphone."', '".$baccname."', '".$gift."', '".$gphone."', '".$gcategory."', '".$available."', now())");
  header('Location:zumyi.php');

}
if(isset($_POST['cancel'])){
  $deletecash1 = $mysqli->query("DELETE FROM cashback WHERE Useremail = '".$userData['email']."' ");
        header('Location:withdraw.php');
}





?>
<html>
<head>
        <title></title>
        
       <link rel="stylesheet"  href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> 
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="store.css" type="text/css" rel="stylesheet">
        <link rel='stylesheet' type='text/css' href='overviewcash.css'>
        <link rel='stylesheet' type='text/css' href='zumyicss.css'>
        <script type="text/javascript">
        	function GoogleLogin() {
				var location = 'gogle/';
    			window.location.href = location;
			}
            function FbLogin() {
                var location = 'fb/index.php';
                window.location.href = location;
            }
            $(document).ready(function()
                {
                  $("tr:odd").css({
                    "background-color":"#fff",
                    "color":"#000"});
                });

        </script>
</head>
<body>
     <style>
        .panel-footer{
            margin-top:10px;
        }
        * {
            border: 0;
            box-sizing: unset;
        }
        .col-lg-1, .col-lg-10, .col-lg-11, .col-lg-12, .col-lg-2, .col-lg-3, .col-lg-4, .col-lg-5, .col-lg-6, .col-lg-7, .col-lg-8, .col-lg-9, .col-md-1, .col-md-10, .col-md-11, .col-md-12, .col-md-2, .col-md-3, .col-md-4, .col-md-5, .col-md-6, .col-md-7, .col-md-8, .col-md-9, .col-sm-1, .col-sm-10, .col-sm-11, .col-sm-12, .col-sm-2, .col-sm-3, .col-sm-4, .col-sm-5, .col-sm-6, .col-sm-7, .col-sm-8, .col-sm-9, .col-xs-1, .col-xs-10, .col-xs-11, .col-xs-12, .col-xs-2, .col-xs-3, .col-xs-4, .col-xs-5, .col-xs-6, .col-xs-7, .col-xs-8, .col-xs-9{
            padding-left: 0px;
            padding-right: 0px;
        }
        .navbar .super-header .navbar-header .navbar-sign-form{
            margin-top: -69px;
        }
        .navbar{
            border:0px;
        }
        .navbar .super-header .navbar-header .input-group-main .input-group-addon{
            margin-right: -10;
            height: 29;
            width:35;
            border-radius: 4px;
        }
        .ntitle{
                color: #4a4a4a;
    font-size: 24px;
    font-weight: bold;
    padding-top: 20px;
    margin: 0;
    font-weight: bold;
        }
        .nstitle{
            color: #9b9b9b;
    font-weight: 300;
    font-size: 14px;
    letter-spacing: 0.2px;
    padding-top: 2px;
    margin: 0;
    margin-bottom: 10px;
        }
        
        .tdata{
                color: white !important;
                padding: 15px 56px;
            }
        .tdtd{
                padding: 15px 56px;
    color: #4a4a4a;
    font-size: 14px;
    text-align: left;
    width: 135px;

        }
        .profile-page-container .overview-container table td, .profile-page-container .payment-container table td{
            padding: 15px 56px;
        }
        .butrans{
            background-color: #cd3232;
    border: 2px solid #cd3232;
    display: inline-block;
    cursor: pointer;
    color: white;
    font-family: Arial;
    font-size: 14px;
    font-weight: bold;
    padding: 5px 10px;
    margin-top: 15px;
    text-decoration: none;
    outline: none;
    width: 161px;
    border-radius: 2px;
        }
        .butrans1{
            margin-left: 479px;
            background-color: #cd3232;
    border: 2px solid #cd3232;
    display: inline-block;
    cursor: pointer;
    color: white;
    font-family: Arial;
    font-size: 14px;
    font-weight: bold;
    padding: 5px 10px;
    margin-top: 15px;
    text-decoration: none;
    outline: none;
    width: 161px;
    border-radius: 2px;
        }
        .contable{

        }
        tbody td{
  padding: 30px;
}

tbody tr:nth-child(odd){
  background-color: #f3f9fc;
  color: #fff;
}
.redrow{
                background-color: #cd3232;
    font-weight: bold;
        }

    </style>
       <?php include('header.php'); ?>
<div class="main">
	<div class="main-content">
		<div class="content-wrapper profile-page-container">
			<?php include('sidebar.php'); ?>
			<div class="main-body">
				<div class="overview-container">
					<div class="profile-details">
						<div class="heading">OVERVIEW</div>
						<div class="info-header">
						</div>
					</div>
                    <div class="ntitle">Earned Cashback</div>
                    <div class="nstitle">Get your click ID</div>
                    <div>
                        <form method="POST">
                            <table class="contable">
                            </tbody>
                                <tr class="redrow" style="
                                    background-color:  #cd3232;
                                "><td class="tdata">DATE</td><td class="tdata">Merchant</td><td class="tdata">Clicked Url</td><td class="tdata">Status</td></tr>
                                <?php 
                                    $projects = array();
                                    $records = $mysqli->query("SELECT * FROM clickset WHERE email = '".$userData['email']."'");
                                    $s = 1;
                                    while ($project =  mysqli_fetch_array($records))
                                    {
                                        $projects[] = $project;
                                    }
                                    foreach ($projects as $project)
                                    {
                                ?>
                                <tr><td class="tdtd">
                                <?php echo $project['data']; ?>
                                </td>
                                <td class="tdtd"><?php echo $project['merchant']; ?></td><td class="tdtd"><a href="<?php echo $project['link']; ?>"><?php echo $project['description']; ?></a><td class="tdtd">
                                    <?php 
                                    if($project['active'] == 1){
                                        ?>
                                        Purchased
                                        <?php
                                    }else{
                                        ?>
                                        Clicked
                                        <?php
                                    }
                                    ?></td></tr><?php }
                                    ?>
                                </tbody>
                            </table>
                        </form>
                    </div>
					<div class="promotion-section cashback-section bonus-table">
					</div>
					<div class="refer-details-modal percentage-details-modal">
						<div class="md-modal md-scaled-effect" id="percentage-details-modal">
							<div class="md-content">
								<div class="cd-modal-content">
									<div class="cd-modal-header">
										<div class="cd-modal-popup-close md-close perc-close">×</div>
									</div>
									<div class="cd-modal-body">
										<div class="share-promo"> There is no upper limit on the number of friends you can refer and also no cap on the amount of referral bonus you can earn. </div><div class="share-conditions">
											<div class="conditions">Conditions:
											</div>
											<ul>
												<div class="referral-info">
													<li> Referral bonus is applicable only on the cashback/Rewards earnings by your friend, not applicable on any bonus earnings by your friend. </li>
													<li> We will credit bonus to your account when your friends cash back is confirmed </li>
												</div>
											</ul>
										</div>
									</div>
								</div>
								<div class="cd-modal-footer">Example: If your friend earns Rs. 2000 confirmed cash back, you will get Rs. 200 as bonus</div>
							</div>
						</div>
						<div class="md-overlay perc-close"></div>
					</div>
					<div class="refer-section">
						<div class="left profile-refer-logo">
							<div>
								<p class="refer-title">Refer a friend</p>
								<p>and earn</p>
								<p class="ref-amount">10%</p>
							</div>
						</div>
						<div class="right refer-details">
							<div class="refer-info">Refer your friend &amp;</div>
							<div class="refer-info">earn <span class="ref-amount">10% </span> of their cashback earnings forever. </div>
							<div>There is no limit on the number of friends you can refer and also no cap on the amount of referral bonus you can earn. <span class="referral-details" id="percentage-details-popup">Details</span></div>
							<a href="/profile/refer">
								<button class="btn-refer">Invite &amp; Earn</button>
							</a>
						</div>
					</div>
				</div>
				<script>GTM_DATA = {page: 'profile', profile:{ 'activity': 'overview' } };</script>
			</div>
		</div>
	</div>
</div>
<footer class="cd-footer ">
<div class="site-links-wrapper">
   <div class="content-wrapper">
      <div class="site-block footer-no-marginLeft">
         <div class="links-header">HELP</div>
         <ul>
            <li><a href="https://www.coupondunia.in/support/faqs">FAQ's</a></li>
            <li><a href="https://www.coupondunia.in/support">How it works</a></li>
            <li><a href="https://www.coupondunia.in/support/missing-cashbacks">Missing cashback claims</a></li>
            <li><a href="https://www.coupondunia.in/support/contact-us">Contact us</a></li>
         </ul>
      </div>
      <div class="site-block">
         <div class="links-header">COUPONDUNIA</div>
         <ul>
            <li><a href="https://www.coupondunia.in/about-us">About</a></li>
            <li><a href="https://www.coupondunia.in/press/media-exposure">Press</a></li>
            <li><a href="https://www.coupondunia.in/press/media-resources"> Media</a></li>
            <li><a href="https://www.coupondunia.in/contact-us">List Your Business</a></li>
         </ul>
      </div>
      <div class="site-block">
         <div class="links-header">MISC</div>
         <ul>
            <li><a href="https://www.coupondunia.in/privacy-policy"> Privacy Policy </a></li>
            <li><a href="https://www.coupondunia.in/terms-service"> Terms &amp; Conditions </a></li>
            <li><a href="https://www.quirkcard.com/?utm_source=CouponDunia&amp;utm_medium=footer-link&amp;utm_campaign=cd-footer" target="_blank"> Quirk Card </a></li>
         </ul>
      </div>
      <div class="site-block">
         <div class="links-header">FOLLOW US ON SOCIAL MEDIA</div>
         <div class="social-links-wrapper"><span><a href="https://www.facebook.com/CouponDunia/" rel="noopener noreferrer" target="_blank" onclick="CD.c.util.logUserAction(&#39;social-fb-like&#39;)"><i class="fa fa-facebook fa-2x"></i></a></span><span><a href="https://twitter.com/coupondunia/" target="_blank" rel="noopener noreferrer"><i class="fa fa-twitter fa-2x"></i></a></span><span><a href="https://www.instagram.com/cdjanta/" target="_blank" rel="noopener noreferrer"><i class="fa fa-instagram fa-2x"></i></a></span><span><a href="https://plus.google.com/+coupondunia" target="_blank" rel="noopener noreferrer"><i class="fa fa-google-plus fa-2x"></i></a></span></div>
      </div>
   </div>
</div>
<div class="cat-links-wrapper">
<div class="content-wrapper">
<div class="cat-links">
   <a href="https://www.coupondunia.in/category/travel"><span class="cat-header">Travel</span></a>
   <ul>
      <li><a href="https://www.coupondunia.in/airbnb"> Airbnb Offers <span> |</span></a></li>
   </ul>
   <ul>
      <li><a href="https://www.coupondunia.in/makemytrip"> MakeMyTrip Offers <span> |</span></a></li>
   </ul>
   <ul>
      <li><a href="https://www.coupondunia.in/cleartrip"> Cleartrip Offers <span> |</span></a></li>
   </ul>
   <ul>
      <li><a href="https://www.coupondunia.in/oyorooms"> OYO Rooms Offers <span> |</span></a></li>
   </ul>
   <ul>
      <li><a href="https://www.coupondunia.in/redbus"> redBus Offers <span> |</span></a></li>
   </ul>
   <ul>
      <li><a href="https://www.coupondunia.in/uber"> Uber Offers <span> |</span></a></li>
   </ul>
   <ul>
      <li><a href="https://www.coupondunia.in/ola-coupons"> Ola Offers <span> |</span></a></li>
   </ul>
   <ul>
      <li><a href="https://www.coupondunia.in/goibibo"> Goibibo Offers <span></span></a></li>
   </ul>
</div>
<div class="cat-links">
   <a href="https://www.coupondunia.in/category/fashion"><span class="cat-header">Fashion</span></a>
   <ul>
      <li><a href="https://www.coupondunia.in/shoppersstop"> Shoppers Stop Offers <span> |</span></a></li>
   </ul>
   <ul>
      <li><a href="https://www.coupondunia.in/jabong"> Jabong Offers <span> |</span></a></li>
   </ul>
   <ul>
      <li><a href="https://www.coupondunia.in/limeroad"> LimeRoad Offers <span> |</span></a></li>
   </ul>
   <ul>
      <li><a href="https://www.coupondunia.in/myntra"> Myntra Offers <span> |</span></a></li>
   </ul>
   <ul>
      <li><a href="https://www.coupondunia.in/lenskart"> Lenskart Offers <span> |</span></a></li>
   </ul>
   <ul>
      <li><a href="https://www.coupondunia.in/yepme"> Yepme Offers <span></span></a></li>
   </ul>
</div>
<div class="cat-links">
   <a href="https://www.coupondunia.in/category/recharges"><span class="cat-header">Recharge</span></a>
   <ul>
      <li><a href="https://www.coupondunia.in/paytm"> Paytm Offers <span> |</span></a></li>
   </ul>
   <ul>
      <li><a href="https://www.coupondunia.in/freecharge"> FreeCharge Offers <span> |</span></a></li>
   </ul>
   <ul>
      <li><a href="https://www.coupondunia.in/mobikwik"> MobiKwik Offers <span> |</span></a></li>
   </ul>
   <ul>
      <li><a href="https://www.coupondunia.in/oxigenwallet"> OxigenWallet Offers <span> |</span></a></li>
   </ul>
   <ul>
      <li><a href="https://www.coupondunia.in/rechargeadda"> rechargeADDA Offers <span> |</span></a></li>
   </ul>
   <ul>
      <li><a href="https://www.coupondunia.in/videocond2h"> Videocon d2h Offers <span> |</span></a></li>
   </ul>
   <ul>
      <li><a href="https://www.coupondunia.in/dishtv"> Dish TV Offers <span></span></a></li>
   </ul>
</div>
<div class="cat-links">
   <a href="https://www.coupondunia.in/category/mobiles-and-tablets"><span class="cat-header">Mobiles &amp; Tablets</span></a>
   <ul>
      <li><a href="https://www.coupondunia.in/amazon"> Amazon Offers <span> |</span></a></li>
   </ul>
   <ul>
      <li><a href="https://www.coupondunia.in/ebay"> eBay Offers <span> |</span></a></li>
   </ul>
   <ul>
      <li><a href="https://www.coupondunia.in/croma"> Croma Offers <span> |</span></a></li>
   </ul>
   <ul>
      <li><a href="https://www.coupondunia.in/infibeam"> InfiBeam Offers <span> |</span></a></li>
   </ul>
   <ul>
      <li><a href="https://www.coupondunia.in/homeshop18"> HomeShop18 Offers <span> |</span></a></li>
   </ul>
   <ul>
      <li><a href="https://www.coupondunia.in/mi"> Mi Offers <span> |</span></a></li>
   </ul>
   <ul>
      <li><a href="https://www.coupondunia.in/shopcj"> Shop CJ Offers <span></span></a></li>
   </ul>
</div>
<div class="cat-links">
   <a href="https://www.coupondunia.in/category/computers-laptops-and-gaming"><span class="cat-header">Computers, Laptops &amp; Gaming</span></a>
   <ul>
      <li><a href="https://www.coupondunia.in/flipkart"> Flipkart Offers <span> |</span></a></li>
   </ul>
   <ul>
      <li><a href="https://www.coupondunia.in/snapdeal"> Snapdeal Offers <span> |</span></a></li>
   </ul>
   <ul>
      <li><a href="https://www.coupondunia.in/adda52"> Adda52 Offers <span> |</span></a></li>
   </ul>
   <ul>
      <li><a href="https://www.coupondunia.in/shopclues"> ShopClues Offers <span> |</span></a></li>
   </ul>
   <ul>
      <li><a href="https://www.coupondunia.in/headphonezone"> Headphone Zone Offers <span> |</span></a></li>
   </ul>
   <ul>
      <li><a href="https://www.coupondunia.in/microsoftstore"> Microsoft Store Offers <span></span></a></li>
   </ul>
</div>
<div class="cat-links">
   <a href="https://www.coupondunia.in/category/cameras-and-accessories"><span class="cat-header">Cameras &amp; Accessories</span></a>
   <ul>
      <li><a href="https://www.coupondunia.in/zopper"> Zopper Offers <span> |</span></a></li>
   </ul>
   <ul>
      <li><a href="https://www.coupondunia.in/samsung_eStore"> Samsung eStore Offers <span> |</span></a></li>
   </ul>
   <ul>
      <li><a href="https://www.coupondunia.in/photo-square"> Photo Square Offers <span> |</span></a></li>
   </ul>
   <ul>
      <li><a href="https://www.coupondunia.in/royzez"> Royzez.com Offers <span> |</span></a></li>
   </ul>
   <ul>
      <li><a href="https://www.coupondunia.in/naaptol"> Naaptol Offers <span></span></a></li>
   </ul>
</div>
<div class="cat-links">
<a href="https://www.coupondunia.in/category/kids-babies-and-toys"><span class="cat-header">Kids, Babies &amp; Toys</span></a>
<ul>





    
 <li>
<a href="https://www.coupondunia.in/firstcry"> FirstCry Offers <span> |</span>
</a>
</li>
</ul>
<ul>
<li>
<a href="https://www.coupondunia.in/hopscotch"> Hopscotch Offers <span> |</span>
</a>
</li>
</ul>
<ul>
<li>
<a href="https://www.coupondunia.in/babyoye"> Babyoye Offers <span> |</span>
</a>
</li>
</ul>
<ul>
<li>
<a href="https://www.coupondunia.in/giftease"> Giftease Offers <span> |</span>
</a>
</li>
</ul>
<ul>
<li>
<a href="https://www.coupondunia.in/kindercart"> KinderCart Offers <span> |</span>
</a>
</li>
</ul>
<ul>
<li>
<a href="https://www.coupondunia.in/kidskart"> Kidskart Offers <span>
</span>
</a>
</li>
</ul>
</div>
<div class="cat-links">
<a href="https://www.coupondunia.in/category/home-furnishing-and-decor">
<span class="cat-header">Home Furnishing &amp; Decor</span>
</a>
<ul>
<li>
<a href="https://www.coupondunia.in/urbanladder"> Urban Ladder Offers <span> |</span>
</a>
</li>
</ul>
<ul>
<li>
<a href="https://www.coupondunia.in/fabfurnish"> FabFurnish Offers <span> |</span>
</a>
</li>
</ul>
<ul>
<li>
<a href="https://www.coupondunia.in/housefull"> Housefull Offers <span> |</span>
</a>
</li>
</ul>
<ul>
<li>
 <a href="https://www.coupondunia.in/chumbak"> Chumbak Offers <span> |</span></a></li></ul><ul><li><a href="https://www.coupondunia.in/pepperfry"> Pepperfry Offers <span> |</span></a></li></ul><ul><li><a href="https://www.coupondunia.in/rediffshopping"> Rediff Shopping Offers <span></span></a></li></ul></div><div class="cat-links"><a href="https://www.coupondunia.in/category/food-and-dining"><span class="cat-header">Food &amp; Dining</span></a><ul><li><a href="https://www.coupondunia.in/dominos"> Domino's Pizza Offers <span> |</span></a></li></ul><ul><li><a href="https://www.coupondunia.in/mcdonalds"> McDonald's Offers <span> |</span></a></li></ul><ul><li><a href="https://www.coupondunia.in/foodpanda"> foodpanda Offers <span> |</span></a></li></ul><ul><li><a href="https://www.coupondunia.in/kfc"> KFC Offers <span> |</span></a></li></ul><ul><li><a href="https://www.coupondunia.in/pizzahut"> Pizza Hut Offers <span> |</span></a></li></ul><ul><li><a href="https://www.coupondunia.in/bigbasket"> bigbasket Offers <span> |</span></a></li></ul><ul><li><a href="https://www.coupondunia.in/swiggy"> Swiggy Offers <span></span></a></li></ul></div><div class="cat-links"><a href="https://www.coupondunia.in/category/gifts-and-jewellery"><span class="cat-header">Flowers, Gifts &amp; Jewellery</span></a><ul><li><a href="https://www.coupondunia.in/fnp"> Ferns N Petals Offers <span> |</span></a></li></ul><ul><li><a href="https://www.coupondunia.in/floweraura"> FlowerAura Offers <span> |</span></a></li></ul><ul><li><a href="https://www.coupondunia.in/zoomin"> Zoomin Offers <span> |</span></a></li></ul><ul><li><a href="https://www.coupondunia.in/monginis"> Monginis Offers <span> |</span></a></li></ul><ul><li><a href="https://www.coupondunia.in/indiangiftsportal"> Indian Gifts Portal Offers <span> |</span></a></li></ul><ul><li><a href="https://www.coupondunia.in/archies"> Archies Offers <span> |</span></a></li></ul><ul><li><a href="https://www.coupondunia.in/printvenue"> Printvenue Offers <span></span></a></li></ul></div></div></div><div class="footer-toolbar-wrapper"><div class="content-wrapper">
<div class="toolbar-ext">
<div class="toolbar-header">
<div class="header-footer-sprite ext-cd-logo">
</div>
<div class="install-text-container">
<div class="install-text-header">CouponDunia</div>
<div class="install-text">Shopping Assistant</div>
</div>
</div>
<div class="toolbar-desc">
<div>Get the best cashback and coupons instantly while visiting your favourite online stores!</div>
</div>
<div class="toolbar-img-holder">
<div class="ext-benefits">
<div class="toolbar-img extension-main-sprite footer-cashback-coupons"></div><div class="toolbar-img-text"><div> Reminds you about </div> Cashback &amp; Coupons </div></div><div class="divider"></div><div class="ext-benefits"><div class="toolbar-img extension-main-sprite footer-special-offer"></div><div class="toolbar-img-text"><div> Helps you find </div> Special Offers </div></div><div class="divider"></div><div class="ext-benefits"><div class="toolbar-img extension-main-sprite footer-top-offer"></div><div class="toolbar-img-text"><div> Notifies you about </div> Top Offers </div></div></div><a class="chromeHome chrome-inline-install make-visible"><div class="toolbar-download">INSTALL NOW</div></a><a class="otherBrowserHome" href="https://chrome.google.com/webstore/detail/coupondunia-browser-exten/iledpgbdhgeianadegpmahgpieckekfp" target="_blank" rel="noopener noreferrer"><div class="toolbar-download">INSTALL NOW</div></a><a class="firefoxHome" href="https://addons.mozilla.org/addon/coupondunia-shopping-assistant/" target="_blank" rel="noopener noreferrer"><div class="toolbar-download">INSTALL NOW</div></a><a class="bextInstalled"><div class="toolbar-download downloaded-show">INSTALLED</div></a></div><div class="right-side-wrapper"><div class="download-app-wrapper"><div class="download-header">Download our mobile app!</div><div class="img-holder header-footer-sprite app-download-bg"></div><div class="download-btn-holder"><div class="download-btn google-play-ctr"><a target="_blank" rel="noopener noreferrer" href="https://play.google.com/store/apps/details?id=in.coupondunia.androidapp&amp;utm_source=DesktopBottomBanner&amp;utm_medium=xpromo"><div class="header-footer-sprite google-play"></div></a></div><div class="download-btn app-store-ctr"><a target="_blank" rel="nofollow noopener noreferrer" href="https://91188.api-04.com/serve?action=click&amp;publisher_id=91188&amp;site_id=71552&amp;destination_id=105516"><div class="header-footer-sprite app-store"></div></a></div></div></div><div class="right-container"><div class="hiring-wrapper">
<div class="hiring-header">We are hiring!</div>
<div class="hiring-desc"><a>The people at CouponDunia are an energetic bunch of people who are passionate about what they do and crazy fun to be around. If you have a sense of ownership and want to learn a lot and grow fast, CouponDunia is the place for you!</a></div><div class="hiring-see-all"><i class="fa fa-caret-right"></i><span><a href="https://careers.coupondunia.in/"> See all jobs</a></span></div></div></div><div class="bottom-level-wrapper"><div class="blog-wrapper"><div class="blog-header">Latest from the blog</div><div class="blog-img"><img src="./Flipkart Coupons &amp; Offers _ Upto 90% OFF _ Upto 7% CD Rewards_files/Blog-Thumb.png" alt="blog-logo"></div><div class="desc-wrapper"><div class="blog-desc"><a href="http://www.coupondunia.in/blog/the-great-diwali-cashback-festival/">The Great Diwali Festival | Guide To India’s Biggest Cashback Carnival!</a></div><div class="blog-author"> - By Abhishek Upadhyay</div></div></div><div class="subscribe-wrapper"><div class="subscribe-header">Subscribe to CouponDunia</div>
<div class="subscribe-desc">Subscribe to get the best deals &amp; Offers in your email.</div>
<div class="subscribe-btn-holder">
<form action="https://www.coupondunia.in/flipkart?" id="subscribe-form">
<input type="text" placeholder="Type your email..." class="subscribe-email">
<button type="submit" class="subscribe-btn">Subscribe</button>
</form></div>
<div class="footer-sub-alert">
</div>
</div>
</div>
</div>
</div>
</div>
<div class="switch-to-sites">
<div class="content-wrapper">
<span style="float: left;" id="switch-site"><a>Switch to mobile site</a>
</span><span>2010-2018 CouponDunia. All Rights Reserved</span>
<span style="float: right;">Indiatimes Commerce Network</span>
</div>
</div>

<div class="scrollup" id="scrollup">
<i class="fa fa-angle-up">
</i>
<div class="top-text">TOP</div>
</div>
</footer>      <script>
 (function () {
 var container = document.querySelector('head');
 var scripts = ["https:\/\/ajax.googleapis.com\/ajax\/libs\/jquery\/2.2.4\/jquery.min.js","https:\/\/www.google.com\/recaptcha\/api.js","https:\/\/d1nrhamtcpp354.cloudfront.net\/modules\/web\/assets\/dist\/fuckadblock.js?hash=4512a9e4577c9893fdab570056c39fd5481b4839","https:\/\/d1nrhamtcpp354.cloudfront.net\/modules\/web\/assets\/dist\/stores.js?hash=9bfb27d674a39df8158113c779b343f3d9129161"];
 scripts.forEach(function (src) { 
var el = document.createElement('script');
 el.src = src; el.async = false; 
container.appendChild(el); 
}) 
})
();
 </script>
</body>
</html>