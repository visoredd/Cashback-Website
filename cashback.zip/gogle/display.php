<?php
    if(isset($_GET["data"]) && isset($_GET["data2"]))
    {
        $data = $_GET["data"];
        $data2 = $_GET["data2"];
        if (strpos($data2, 'amzn') !== false) {
        $data3 = "AMAZON";
        }
        if (strpos($data2, 'voylla') !== false) {
        $data3 = "VOYLLA";
        }
        else{
            $data3 = "FLIPKART";
        }
        $today = date("F j, Y");
        $mysqli = new mysqli("localhost", "root", "", "cashback");
        require_once './user.php';
        require_once './index.php';
        $insq = $mysqli->query("INSERT INTO clickset (email, description, merchant, link, data, now) VALUES ('".$userData['email']."','".$data."', '".$data3."', '".$data2."', '".$today."', now())");
        if($insq == FALSE){
            echo mysql_error();
        }
    }

?>


<!-- saved from url=(0169)https://www.mysmartprice.com/out/sendtostore.php?access_point=desktop&store=coolwinks&l1=cashback&top_category=offers&url=https%3A%2F%2Fwww.coolwinks.com%2F&ref=bonusapp -->
<html xmlns="http://www.w3.org/1999/xhtml" class="gr__mysmartprice_com"><head profile="http://gmpg.org/xfn/11"><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><style id="stndz-style"></style>

<style type="text/css">
  .status,.title{font-size:18px}body{margin:0;font-family:Arial,sans-serif;background-color:#fff;color:#333}.gotostoreWrapper{margin:auto;position:absolute;top:0;right:0;bottom:0;left:0;height:75%;text-align:center}.msp-logo img{height:42px}.title{margin-top:20px}.title .red{color:#c00}.status{margin-top:90px;font-weight:700}.status img{margin-left:5px;vertical-align:middle}.loading{margin-top:25px}.store-link{text-decoration:none;font-size:12px;color:#666}.store-link:hover{color:#999}.offer{margin-top:90px}
    </style>
<meta name="googlebot" content="noindex">
<title> On your way to the Store </title>
<style>
.en-markup-crop-options {
    top: 18px !important;
    left: 50% !important;
    margin-left: -100px !important;
    width: 200px !important;
    border: 2px rgba(255,255,255,.38) solid !important;
    border-radius: 4px !important;
}

.en-markup-crop-options div div:first-of-type {
    margin-left: 0px !important;
}
</style></head>
<body data-gr-c-s-loaded="true"><div id="touchvpn_icon_container" class="disconnected" draggable="true" style="right: 1.09809663% !important; bottom: 2.55102041% !important;"><div id="touchvpn_status_icon" class="touchvpn_ru"><div class="touchvpn_icon_sign">Best choice for browsing</div></div><div id="touchvpn_icon_selector"><div class="touchvpn_country touchvpn_ca"><div class="touchvpn_icon_sign">Browse from Canada</div></div><div class="touchvpn_country touchvpn_nl"><div class="touchvpn_icon_sign">Browse from Netherlands</div></div><div class="touchvpn_country touchvpn_de"><div class="touchvpn_icon_sign">Browse from Germany</div></div><div class="touchvpn_country touchvpn_in"><div class="touchvpn_icon_sign">Browse from India</div></div></div></div>
<img src="./On your way to the Store_files/log_gotostore.php" id="image">


<div class="gotostoreWrapper">
<div class="msp-logo">
<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAe0AAABACAMAAAAAn99NAAAA/1BMVEUAAAAmhnIHkIMJkIEIkIAIkYEMjYQJPmsJkYHfohkIkYEJPmwJN18IkIAKN14JkYEJPmsIkYEIkYEHWHgJPmsIkIEIkIAIPmwIPmsIkYEJPmsHkYAJPmsIkIAIkIEIkYAJPmsIkYAHOGEJPmwJPmwKPmsAAAAJPmwJPmsIkYEJkYAAAAAJkIEAdL0Adb0AAAAAdL0HkYEAdb0AAAAAdbz+wQDdoRoAdb0AAADvsw7ytQvztgoAAAD9wAHssA8Adb3doBvkpxcFWJIJkYEKP2z/2j7/wgEAdb0AAAD+0i7+yBPfzUL42D/usQ4dl3yStFcZfWVwr2RBlWa9xE0Kh3avtLZNAAAAQ3RSTlMAByf48NUS9cH+qOUlOA3gzE51GNiRfnJX570dnp1bZmK0Na1KQet9jcuHrzDVUceuQ/NlNeTXi0EUJY6Fvk5uqmvz2M36+AAADpFJREFUeNrsmt1umzAUgG1sIxoJIZiChBBBXBKxapnWTW20atPROiXZmu7n/Z9lMSX4YAwj283k8fWigTiE8NnHxz8EurCkLJa575IZGwEj3FtRMmMdMASPUzJjGTBMsiIzdgFjLOdwbhcwyprM2ASME5IZi4BxxBzLbaKj1iuDhM2N214AIXNwmoYeIAoyYw+6bckKtW9OZuzBZJtkoJgnUS3CaNsHhUNmrMFo20GhvCIz1mC2DYp5ttwijLZXE7K021tKJuA6jpNS8qdQp/L9sQtQ13Xn1OJvbFOhzi1IH3q3fX/z8PBw83573/EQxi31+TQW7HkBNW+NOF5LjD+atZyjCd0sAwY1TCzDnnLqREXAakSWVxS/FcU1Tn1QxR6XhRZ55xp5XBMSSRoVCWMsKKLK4gklg22/BIXfb9QfpekzN9s70rKEFkoIXXO8gEqbq5trUtSeZU4jLIEOrMxdLDQX0CHI1L26zTeH2s9hXqhcCnUX6YJBi4is9Q2IuKo2+VIAwqNE4166xlxtqdF2WkIHz73EtiOgD49ULEigjwipbpuuoUuR9m2HXKs4PrETGIVXesN+LwXv97vdp91ut691f317Z7CdBqBR0um2fQ4mEvIMzcCMV3VtGwomG912DjosIlYyLluv43c30vXuU8uu1n1137PtltBjOdm2GwzIbGQXMASLKLa9HvhV2PaGQR87dcMInmOSLV0j9jKYX93ptjOTiWqq7RjMrJXsQQpke82MESLFtr3k/1nrhWFE7o7Kxrrf3irbwywm2qYczIR6pWLcKxae4MhqgGyz5l8iRIKKeMq2ggsRcFQlbBzXwRg8c7Q+W8lW1LH8wxTb3J1m2wcFE2WZnF/XjdJn7XuZT4mEVlGp2Vbw54EYXtxb6bbZor4S9VVynhH7+J2fnLRsG9lfFK1uGct7trm3WAjAbKbZjlAZl55ww0waT2hnNkDgukhDbrZdpmqEfVYpaNd2ohIUv61aFq4QwO/I6DmOn2U/tjz9eI7l0vaHnu2lWz+9AJ+aZnutNNDW5qZgdQQO8ZAOE2Pb5jHkChr8jm2OxTqJvZvyYAhsqOYUx/fS7QFang7nxPzr1dUtso2z2pSjDvNS2wHFHupu21Md6wTbPCWYDIVpMZCRrezdpQWIcnHCC5ieGrVNu3Z7OB6P3x6l6sMBh/KPXdseVRaUvGm2c9MmZ73yrMiobXMph6mYIQb251Bh7YJQf+aUurkw7ETcdjK0H03DRrY/dG1v9Ccs4ZdnaWLV9R2quxq3bS7lqU5ZDMwOt5UtJ7ah2W7Iud646Wn01Yj+/nj6O51+lL5Vx/0W28YhGKdM9A9GYHwRola2Vh3FBNsxGTAZKtuCaDjM1qzcbJtsmDZfcS977ZrjNwnA0/H4qWObYtv4SSWX2q6PMLxoVzMKLcyO2mYV0fBVZRFD9YYGalh+OS/eXF9f/6P5vNG2ll5zHMgb5fDzuzrCtg1RsLzYNi1Bh68dIglUxztu21wqVbmnGNyLJVSjvwz65t3LzzWvX13/g9Mzv9o50+a0YSAM73KZYuMa7NTGECDGBkJSIG3a9EjPZFp6z/T//5hqJRfJF0fvaft+ICCtjZNHe0iWU0S7pHaUeEX+Ji7SWHVGrv1uI+2mmiv3pg3KPRXZMSN25biihIwOs7TrWR4y9sRMKwhp1b9xv+05Qy11ew5/mopo40214lLTNjUwz+awi/N29/toQzdvLfyYdRXvc2+otAszrzy+WjjRauTQtg0TNgsvhFffZrrD3y5t+LNUSPs4UaY9JNpxDKeUTaylXmVp4560Z5ndDK0c977Z3UC7mqXdziJRaBdGieMc2ifju1tgL4VD15DmNefi0x+WvwtpV9O04yLt3Ufm2ev6TFldebwb7dN82ocqbSHsH1XSuOtYGKNrnV1od5VIXhjt5bhRaK+KaeMwMmyE82fLuZILlxdzG0wj8EL4lcLhyNubdiXftymUU9JO0b5Bqys70e7m0z5WaUuCg3p6qacw/pbKWdoDSOtMTs3k3pWCcXO8K22wrjVN96dDG1QZw5Gla9fXQ/jhMqe9ngG5Cq6vNWNP2s2r3LxN+kRp+306kN94tC9t1auwnKYtgR+XVec+KqqtBldZ2q2Cwp16immfytG4I+1QuxbyQ/zKY+h8bUP44TL16+uo4FrYVwb70UYipJZc9+QM7P1nGctlIL8PO9EWIDL+2bpK05bCZlWdiK1HYEr1XWhjNbOW1igcEe0UbeNkvLgk931wGZO/e2nEDkW4BVtbNBBrrpEJpF9GG0d6D/eijbeusvNtkbj5XbD0uikF8h1p403JtSsHV5o2ourfCu5Bwe3n5tV22tKqg8W0sSMnnirtkzHTavyA0V6NOUJ7PLbjNPL69cuRrxNdnRzLI/qaM3rJCnOIZXheYHquZwLY7IcBpud5/PiI9bC2yXRopM2oBQCNoetyW8MwTDRCCiZuFEAQRbYZeSF1mawP7NCOogjoY0An+vrNnoFFtM/qmS0nTxnTNW2eut/L6dcHRvvhrrQVcreka6dpHx43s/MzUrOce3ML6zvRrstfqZB2Wy7+JmivFoZpnBBoc7x6wF17dQJCF6z+RjCHOkEOBOyRgfCMzchsEJowx6d+y3b5WHCR+f+EuFBuD/hQ0XroMgsKDI49FGYAkaXxTg+AWU19jb2SdGCGPT22Ctkx7MxD9pHGmxh6QwCzx8/j26kdxs1m86zfbnRyboI9jO9uy9XT2LnfCNd+DDvShoYCNibarKRptwjDad7W5a4Elka0tUqTVmeS9hGmsnYl9/42xwyAC8rflwLzgqCTkC2rXHCHGtGfONTohXs/m3jPJW0hYslHhcveIwNDdRWDQxB9dNNmEfTYq6aRFegCM+enOUQ7lku0SYL2+ixD0ydbOp8JV1sl74GRc0spsJlwZ9qDxAbxEmKJ9gomaXc78fMCXRFrKrIX+1c5NAblXNrlWwmU/bJ6I6Qqd5grKsm9KynalyD8eQEQcPTGaowASag4FX9b3QAuGgYKbT/kzH1vwmx6tsazr8/ehuTzZuAH4PJ+V1ubjcB0JoZt8EigE+ueS4MjsG1O249Ci0YCp+1P6QcYdAnTicWuw2XvPGNIQWEX2n3xNBDtLc6FTXH8KexM+/QqX5K2msarh7MDNa/UlcTf+IqpJr9Y0o4/9Wvr7D8r2JdWmckCol8p2Jd2EvtxwBHHHn4JQudsJcWGyB+FgKPYIe2J30MK8UtJW0dAh3sZ+atFtiMwyM0j9jLhuZXomICWMJuSGZh2EATsiB7R1m1RpdF4ckR0oGEzIcwTAINoT8XRMIyQWYamaU5Yy1ba8rd+TLgLYD+H3WnDza2028W9AzXJV44GzdJp65AI5dImdRrMqFZqHXRSOy2q6hND7TNm07wl2yq1XNrk0KbwcKRALmmL6DkktyIsaHG4c5bQlbwNwpOJA8MIxNjmQE3yUs3yEFxhNpJmaIi8LWhTs6QtMj/RHYU0EGLa1nqWb5OXM1Ei2Epb7kHBJ4T7jcr6bQz7Pu5BO59lRaFNhViBbmLxdvLUymmxKiWQtAtU7kOxb/Nq3KB3CdrkXA7yLGtQMiavnCd8uydoT7/SJseb6JR0we5xoiN02UuSNqGlxB3TdlXaMVVX0HZQ0o6ARINvra20G6huJxe8JesY9kPYh3atk0NxppRuG5y/JSdkadVv7Ui73ILttA8gQ/uuzNv8IwXyRCQ3LUIDAcVMGGq8hn62kTZR0si/OReX/NvI0o4oM9j2NJ92D+KThnTGmLYvzMAwTY2lCFdoC+3OABQ9Iu8m4CTx9oaAvRdt6Oc8b9aWME7l050Fj2eV8m6Y1HakXR7AdtoHkKW9QF6HC8YPVovxygBIVGkYBQiAGidgR9S9pCqtmLYtHJqK+QABySVzaesmH0sjlXaIIRUBWogm5ZBQpe3SADHNUB8hfR+5PMWAjaxvpXLXQ8rdUtyx6RHPPWnDLA37LHnHs0a8izjl3w+tlmA32p0z2Eq73MYc2qtLBPNSTMRoyi2cXJ2Bxepde+sOGgYbaDMWTAElXs3q9TTm5lnaNCQci8K5H9Pm40JzNM/hUzXqslClbVKHTu2TgI4e+RodV/gLd+TmINW9H99Lsr7/FGBv2tAup0glaIuns8vpK5KPpVF/J9HXqEEe7XZDYpeGSdr1WSf3QdGsb6/GC76WRsLLlQjt6upKLE8zIdacVlc20AZP5HqYcienrixtnPIuXaENEbf3HWrmnTaotIHmayTLBpdM+cJNDu3KzerRQf8UIV8Pnz75wESkiTXCt9CGkqyjqwOENG3S6a3jslpZNyEhHNQrX484or482i3oSjPWdVACyD6tj61GR6nzzyBPl4sHdxfj8YkBJL56asve0mvpw4CB6vNLiDW0rAmVz5blEmbL6kE8dwKCNLEcxx/yjimZCeuQmSF6vu5MA+rwHWcIpMjX9Z7tMPiuQ+9Yi+OM6ESWRdDNoU/nQyose47ujCK6zIRqSIItevji+f37N+4/f/EIkqrJM4Gibl4zNtsHh4eH7XhYoVTC5vCIiVtJye7BbDa71apB4hQJ2vFZGkeNg0GJurK0uU1pcNCgL2oiFEtenFg1VbSUTixFNdrrcyiWZxsUvNen3/TVmUtAFDX5ui2NTjX9+56EkJK0i6XS3l9isi11fkfG8kTjEooV8GmVD98sQftf10+mbT54EJfoauZmZGuQGQE2FMsXy+X/af/RtJlji2otGcsZ23PF6BmDfYcaChWwStmJ4Ds0siwP/nX97Eh+d3ESZL5zybeZniNHXZvfpv2nc9goNE2Eb9G/kZD/ENqbdhjfXl5cLGmLMXf1/8ro76ANQP4sdefiD3xa5G/Ub6INOF+SU5NuX/xhe8n/Xv0m2iQ8nz+7eDa3/+fTIv1NtP9rm/7T/q/vpV2uHp1uo12+Wf/7/gPDv6bazfrsrIawUdXjg373n0qvXwCT7hDLRPGF6wAAAABJRU5ErkJggg==" alt="BonusApp">
</div> <div class="title">10 million+ products. 100+ online stores. <span style="color: #0d426c;font-weight:600">find more. save more.</span></div> <div class="status"> On your way to <a class="store-logo" href="https://www.mysmartprice.com/out/sendtostore.php?access_point=desktop&amp;store=coolwinks&amp;l1=cashback&amp;top_category=offers&amp;url=https%3A%2F%2Fwww.coolwinks.com%2F&amp;ref=bonusapp#">
<img src="./On your way to the Store_files/coolwinks_store.png" alt="<?php echo $data3; ?>">
</a>
</div>
<div class="loading">
<img src="data:image/gif;base64,R0lGODlhzQAfAPUCAPz+/Pz6/PT29MTCxMTGxLS2tNze3NTS1Nza3OTm5NTW1MzOzOTi5Ozq7Ly6vOzu7PTy9KyurMzKzBQWFISGhIyKjAQCBAwKDIyOjAwODBwaHCQmJAQGBGxubISChBQSFKyqrJyenJSWlBweHCQiJExKTDQyNGRiZFxaXDQ2NERCRFRWVDw+PExOTJSSlLSytKSmpGxqbHR2dJyanLy+vHx+fCwuLKSipCwqLFRSVHRydFxeXDw6PHx6fGRmZERGRCH/C05FVFNDQVBFMi4wAwEAAAAh+QQFCQACACwAAAAAzQAfAAACrZSPqcvtD6OctNqLs94ceA6G4kiWkIea6sq2LJq68kzXDBzb+s6DONwLCoeOH5CITO6MOKXzuWIGjtCqNSP9XbfcU1bbDYsFxgNz3Jp+1+y2+702nxXwuv2Oz+v3+MQcwRcoOEhYeEf3R2a4yNjoeLhQZvBI2YeWVpZ1ufmUKckJiuQWSirKVoo69JXK2qPZCqvzGUtLA1aL69KUy4sJ0AscLDxMXGx8jJys3FMAACH5BAUJAAEALAAACABjAAgAAAVCYCCOZGmeaKqubHsCbizPdG3feK7vfK9KhKBwQCQafMgbzKSZfDKXKMdC3XSS2J3zKaVWr9mwDVOhlD3oNKYgbs9CACH5BAUJAAAALAAADAAaAAQAAAZBQIRiSDwsjpKkksAcOJ2JE2rVKqlYKRNuQxppPpkwZ2wpmzBSqhWr5Xon4Iu8bMZE7qBbaC/qY/4VFIIehIUiBEEAIfkEBQkAAAAsAAAMACcABAAABlvAh7CRKDKOhiRCwTw4n5IoQTodWK+PwgvGFbkonp6sEzuhcq2SipfCuUmjifxC51juFl5EC7qFvBVhY2YrhWttJm9xc3V4eRFLUFU0Dnx7XX+AX4GcgjWfNwpBACH5BAUJABgALAAACAB0ABEAAAa1QIxwSCwaj8ikcslsHgPOqHRKrVqv2Kx2y+16v1eAOEAWmCHodGOdaDMMcIRcQT8s7JK8nsAf+P8KEGBJUFlnD25zfQURMDchIhUUHj06HT4omS0/KjwpNjgbIxoTpRenHBaqFi0Hg68YZYhvdXuNj5GSNZaYmpyfoKKjpqirrAuwg7JqbHG1towgt7i5ki66k9m7uzANyd/g4eLj5OXm51yF6Ovs7e7v8EjqsfH19vf4+YZGQQAh+QQFCQAdACwAAAwAPwAEAAAGdkCAcEgsBgRHJGT5aDYS0CjDgKhaD9iFVsLtEr6DsNhIZkqzNMcrAgrNXBhKraeLnXarXOnH4qVsOBsjGhMfhhcciRaLKWVlT1RoBZNtb3Fzdnd5fH1/goOFGYiKixaNjo9OUwpXW2Jqa5U3bpZwFbdyuZgeM0EAIfkEBQkAAQAsCwAMAEEABAAABnBAgHBILBoFSIjywUw4GVCDFKGgHq6LrGRL4HYH4DDiSF4+q9/CCwS7zVwVSk2mi+3uuRJrb7Jt/hoTHxkXhRaHhz5lZWdaNA5rbSJwcnR2eHp8fiQjgYOGiImLjE2NWI5hkRFsIW5vlBhxsh5ztS9BACH5BAUJAAEALBcADABCAAQAAAZ3QIBwSCwaBUjIQ9loJp6MqGGKUFivh4VWwu0SvoNwOHEsM6HVLa3wAsFCM0yFUpN1YifUqlVSsVImNhskIxofGYgXHBaMjCJmkE5YEmxucC5zdXd6e31/gYOGE4eKi40Wj5FmklKTXJUObRGWl3GYcpl0Hpp2EkEAIfkEBQkAJQAsJAABAEoAGAAABv/AknBILBqPyKSymBAsn9CotBgwoCKQqXa7tV5WL654jGTcPpbPDkFujwUwXjrdcdu1DtSFMx8NHneBSg07I3xzFj8KgoxUNTh7HB02cxKNlxAHGhkXGmseG2kEl40EK5wfLE0GHqKkggegaC0gQ6YWo1IAu7y9AQLAwQ8Qww3GqwwGygjMCs4HC9DREjImsyJOQpkaEgFHvr/g4cXHzRI0BREgNyEiGBU18R0+Jyg5LT8qPCkmOBsjACdocMGGiAAKDMqIGyfO2LNz6F7AYDcDngd59Ozh09fPH4lNE3wsMvLrycKGxJQJWGZuWkSJE9dRrFjBxbt3CLK92smzp88Sn0CDCh1K9CeAooy8IV3KdFAQACH5BAUJACEALDEAAQBDABkAAAb/wJBwSCwaj8iksKFsOp/QYqJHE0SvWOiUJxtkv2Bio/BLcQ3h9DXg8PFMthJFTXdKPGVzXAKp+6UUKyxvNjg4KH+JIQA3J3kVOYYbLgqKdAIMKCU/LR4JInkpIgGWaQh4LSUxDQAMMxskGjkwpWCump00Qws6IxojJWhRAMTFxscMmMoPzK0NCc/JBgiNmj4vYggpsRurSscB4MbM0NELBAMOBS8wNzMiGBQePTodPjuaEQxGoBP+DkyKhIMgbmBBcggOnEu3DoQ7eBXoyYhxDwWGfUYgxMDx4cOPAqSGPABobInBg87KMVCYcCE6dTAjgEiGhIYPfxd0eFniIEXIX1pfBIAokSEDCRkBI+SwYAWoLRi/OJioEKLNBaZOw5wqarQnV4JZgwqw0ZGDBg4W0jYN++UV2rRpN/xkiyWADBJwpQ6YS/cKr6tSRfRNQ4OojRlrB2cRiuOGMMVP+QYBACH5BAUJAAYALD0AAQBCABkAAAb/QINwSCwaj0dIAMlsOp9PAASkWEKv2KxwSqFqv2Aj5ODydB/h9FcBqlBqlYh6DmU4RG64ByGg+8U0IXhvMjouCX+JQgdtZQVlOjEFDIp0AQ+NM5OBHTEyBZVzDQMwNyEgSpiRJ12hYWMRpZNDDDAxOz57f6lSvL4PApfBwmyxVFZbhSisEEhjBNDRA9MSfL3XvtgJ2wgKC980Di8gx0UBDjK4K9VHIjwfGRcc8xb1IzHYwvna3ODRVGja3WohQ4IRAjgmwJNHzx6+ffqyRezXrQoTBS5W5ChxiMiAHBoUktBD0sULV0zO1di4QkRAdCNC8qjRB2UWVSV+nLhhYEAHTxsxbdC0+aWBOxVICexIQaJpBQVEwTQ48YMFj6obmhZEFjXLCx9WTSS0oQJYV6kzcjAFmkMCgLNhMIbdCVeNhJ85QNRV80BBXkR705zTEgQAIfkEBQkALAAsSgABAEIAGQAABv9AlnBILBpZAcBxyWw6n8YAA6KEWq9YoVRhgGS/4CjEcCgLwugsQJBAcMvpOHTrXkgkj4B8L27X7wdefINIDVN/BDRdhHJrhgxdW4kDCFWMYUmPCZkMkwQMl5icDURjNA4vNIKhfWyODa+PlpKpBHpHbG9lu4CevgPAU6+xjsRHBqcgMFNHLzIrOSrSKSY4GyQjGh/bFxzeFuA4GMMCxMWOuHYRMAWgpQkdO9El09XX2RMZ+t/gFiYU5AKes1SkgYR1MygNGVPhBApoISLOmOgCg8UKFDJ62MhRBIFBAJDBiDjgDIsDIWLI0wHjFqsrbJSJgCHh5A0dKjvcePDyC0M5iQZm1Ih3IoK7nmpkYhyKM8QipF8UgLjItEY5qGEIRNToAgFWNAapfvwKdmpXsmnYeOSJNk0lRkEAACH5BAUJABoALFcAAQBCABkAAAb/QI1wOAQQj8ikcslsEgFQp3RKVUKv1ax2ee1uv98uFkyeisXlNPc8VruF7ID37Y7P6WSj/Y7f6ttsfWF8cVYQDQmIiQwGjQiPCpEHC5OUEpeYBJoDnJwNGn9RT4FIBg4gMCEiGBUePTIdMScoKy0lKjwpOLskIxO/F8EcFsQWLCB6oIZXD3Kjp6mqLhSusLO1tiy5Jry+Hxngw8XGIHBNcnKLRQDQqJmdBS/yqDf1M6vTrK3U1a89IQqooHvAKACcBJwiOFggyE86RaAQwDsgoKFDRQYOvUNg8SIjSJkgdASjEaQmgyNJfrT0IGUegp4+uXzpyMhMlY9Q3lSp82YQACH5BAUJABAALGMACwBBAA8AAAawQIBwCIAYj8ikcslsOo9E4jIqqFof2IZ2y+gavorwYUyWmAln9GDNpgqVRK74/ILdZiIMpceP+XYoOSU/KjwpNjgbGosTHxePHBaSkm5vUENyZQ4FdSGeeh59f4GDhoeJJIwZq5GTkkZul5iZXghzY5s0up12vXh5oBV7ocR9sLGzXEVPzM1OyLHO0tOylVLU2NLWcdndztsB3uJP2+PmTdHn6nDc6+7VAu/yx8vz3UEAIfkEBQkACQAscQAMAEAACAAABojABGBILBqPguRj2Wg6DQwoYko9WBdYiXZL6A6+X6SYGa3SHIUIKDRzYSgenfy0y9l/LF7KhiP5Jx8ZghyEFoY2YxBIT1NeL2o3IpJxPXN1d3l7fX+BF4WGh4mijGZcZ2mQMJFsk2+ucJSUM0gJtba3uLm6u7y9tUa+wcLDvEXEx8jBxsnMzbVBACH5BAUJAAEALH0ADABBAAQAAAZwQIBwSCwaBUiI8sFMOBlQgxShoB6ui6xkS+B2B+Aw4khePqveVwR2m7kwlJpMFzvtcniW3mTb+DUTHxkXhBaGhjtlZWdYNA5rbCJvcXN1dyWYe30kI4CChYeIiqNNjI1fjwVqIKwhbW6ScBWUtJQRQQAh+QQFCQABACyJAAwAQgAEAAAGdUCAcEgsGgVIiPLBbCSejKhhilBYr4eFVsLtEr6DcDhxLC+h1S2t8ALBQjNMhVKTdWIn1KpVUrFSJjYbJCMaExmIFxwWjIwYZpBoWWBtbyIuc3V3ent9f4GDhYeJi40Wj5CRkmmTlA6vlW5wcZeYcnS4mnYEQQAh+QQFCQAUACyWAAwANwAEAAAGX0CAcEgsGgVIiHLZaCaehihiqqgeFlesZCs5epkMaXVAK0RAt5AIU/HUdB3fCZVrlVS8lMm2GfknX4FOVGRmMGkzbW5wcnR2eHp8JBoTgIJfg1SaXGUOhmeHiGsubGxBACH5BAUJAAoALKQADAApAAQAAAY7QIBwSCwaBcgHRNloJp4MgxRBPVqZ0MOCMHAUIqCQGEPx9HQd3w51bU+33W94XD6n1223862Fx+UvIEEAIfkEBQkAAQAssAAMAB0ABAAABSAgII5kaQoopD7s6a6JoRwLMThF9L6xTNs43Y4n6s0UIQAh+QQFCQADACy8AAwAEQAEAAACCISPqcvtH0QBADs=" alt="Loading...">
</div>
<div class="message">
<a class="store-link" href="<?php echo $data2; ?>">(Taking longer? click here)</a>
<br clear="all">
<br>
<br>
<span class="store-link">Ensure you are logged in to earn Cashback on this purchase.</span> </div>
</div>
<script>
	var url = "<?php echo $data2; ?>";
    setTimeout(function(){
        window.location.replace(url);
    },5000);
    </script>
</body></html>